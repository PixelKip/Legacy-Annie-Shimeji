Thanks for downloading! :3

Lil Rascal/Legacy Annie is from FNF Hazy River, credits to the Hazy River mod team:
Atsuover, Rageminer, Nicky, and Dyl 

Code based on Typhra and Saubin's Spamton shimeji (because I couldn't get window functionality otherwise)
